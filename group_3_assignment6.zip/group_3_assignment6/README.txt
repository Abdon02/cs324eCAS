Be sure to have Processing downloaded.

This is the process to run the animation for group_3_assignment6

Steps:
1. Make sure that inside the folder "group_3_assignment6" has the following files:
	"Board.pde"
	"BluePiece.pde"
	"/images/blueFish.jpg"
	"Cat.pde"
	"group_3_assignment6.pde"
	"assignment6_description.txt"

2. Open the file, "group_3_assignment6.pde" and hit play

3. Enjoy the animation, and observe which character reaches the bottom right corner first to "win"!

4. Inside the file, "assignment6_description.txt" it will contain the desctiption of the files that were used and created to complete this project.