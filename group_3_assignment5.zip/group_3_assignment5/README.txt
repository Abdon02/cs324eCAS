Be sure to have Processing downloaded.

This is the process to run the animation for group_3_assignment5

Steps:
1. Make sure that inside the folder "group_3_assignment5" has the following files:
	"Comet.pde"
	"planet.pde"
	"SpaceShip.pde"
	"Star.pde"
	"group_3_assignment5.pde"
 	"cometTexture.png"
	"earth_tex.png"
	"moon_tex.png"
	"assignment5_description.txt"

2. Open the file, "group_3_assignment5.pde" and hit play

3. Enjoy the animation!

4. Inside the file, "assignment5_description.txt" it will contain the desctiption of the files that were used and created to complete this project.

